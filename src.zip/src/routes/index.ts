import departmentRouter from "./department";
import staffRouter from "./staff";

export { departmentRouter, staffRouter };
