export const URL_PATH = "/api/v1/departments";
