export const URL_PATH = "/api/v1/staffs";
export const DEPARTMENT_URL_PATH = "/api/v1/departments";
