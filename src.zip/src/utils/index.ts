import { IDepartment, IStaff } from "./interfaces";
import { isDepartment, isStaff } from "./interfaceCheckers";

export { IDepartment, isDepartment, IStaff, isStaff };
