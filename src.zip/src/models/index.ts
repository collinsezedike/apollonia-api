import Department from "./Department";
import Staff from "./Staff";

export { Department, Staff };
